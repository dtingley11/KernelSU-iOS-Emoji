# Magisk-iOS-Emoji
Systemlessly replaces emoji font with iOS Emoji 

## Changelog
v1.0
-support for KSU

## Changelog for emojis
[17.4 new emojis](https://blog.emojipedia.org/ios-17-4-emoji-changelog/)

## Troubleshooting 
If it doesn't work delete all files under /data/font/files/(Random folder name)

## Tested on
Pixel 6 (A14)
